const l="/assets/logo-full-C3PiXnOD.png";export{l};
